	<div class="header">
        	<img src="imgs/banner3.jpg" />
        </div>