<div class="footer">
	<h3 style="text-align:center ; line-height:120px; color:#fff; font-size:24px;">Copyright 2019</h3>
	
</div>
    