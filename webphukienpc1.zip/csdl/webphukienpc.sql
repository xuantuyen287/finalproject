-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th12 08, 2019 lúc 08:09 AM
-- Phiên bản máy phục vụ: 10.1.38-MariaDB
-- Phiên bản PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `webphukienpc`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `admin`
--

CREATE TABLE `admin` (
  `idadmin` int(11) NOT NULL,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `admin`
--

INSERT INTO `admin` (`idadmin`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `fullname` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `cart`
--

INSERT INTO `cart` (`id`, `fullname`, `createdate`) VALUES
(1, '0', '2017-04-28 16:49:42'),
(2, '0', '2017-04-28 16:51:15'),
(3, '0', '2017-04-28 16:53:53'),
(10, 'admin', '2017-05-01 11:42:20'),
(11, 'admin', '2017-05-01 11:45:21'),
(12, 'admin', '2017-05-03 14:20:16'),
(13, 'admin', '2017-05-04 02:53:38'),
(19, 'admin', '2017-05-24 06:18:44');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `cart_detail`
--

CREATE TABLE `cart_detail` (
  `id` int(11) NOT NULL,
  `cart_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL DEFAULT '1',
  `quantity` int(11) NOT NULL,
  `price` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `cart_detail`
--

INSERT INTO `cart_detail` (`id`, `cart_id`, `product_id`, `quantity`, `price`) VALUES
(1, 1, 62, 0, '0'),
(2, 2, 60, 1, '50'),
(3, 2, 61, 1, '50'),
(4, 3, 45, 5, '60'),
(5, 4, 39, 1, '50'),
(6, 5, 62, 1, '50'),
(7, 6, 38, 1, '50'),
(8, 6, 39, 1, '50'),
(9, 6, 45, 1, '60'),
(10, 7, 40, 1, '50'),
(11, 7, 48, 1, '60'),
(12, 8, 48, 1, '60,000'),
(13, 9, 84, 7, '199000'),
(14, 10, 81, 5, '1290000'),
(15, 10, 79, 3, '1990000'),
(16, 10, 65, 1, '199'),
(17, 11, 83, 3, '199000'),
(18, 12, 86, 1, '27000000'),
(19, 12, 67, 8, '249900'),
(20, 12, 85, 1, '12000000'),
(21, 12, 72, 1, '40000'),
(22, 13, 86, 3, '27000000'),
(23, 13, 84, 1, '199000'),
(24, 14, 85, 1, '12000000'),
(25, 14, 84, 1, '199000'),
(26, 15, 88, 2, '22000000'),
(27, 16, 86, 3, '27000000'),
(28, 17, 88, 1, '22000000'),
(29, 18, 86, 1, '27000000'),
(30, 19, 85, 1, '12000000'),
(31, 19, 86, 2, '27000000');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `dangky`
--

CREATE TABLE `dangky` (
  `id_khachhang` int(11) NOT NULL,
  `tenkhachhang` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `matkhau` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `dienthoai` int(11) NOT NULL,
  `diachinhan` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `dangky`
--

INSERT INTO `dangky` (`id_khachhang`, `tenkhachhang`, `email`, `matkhau`, `dienthoai`, `diachinhan`) VALUES
(33, 'lnxt', 'admin', 'doimatkhau', 3, '3'),
(34, 'pqt', 'admin', 'doimatkhau', 3, '3'),
(35, 'xt', 'admin', 'doimatkhau', 3, '3'),
(57, '', 'admin', 'doimatkhau', 0, '');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `gallery`
--

CREATE TABLE `gallery` (
  `id_gallery` int(11) NOT NULL,
  `id_sp` int(11) NOT NULL,
  `hinhanhsp` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `gallery`
--

INSERT INTO `gallery` (`id_gallery`, `id_sp`, `hinhanhsp`) VALUES
(23, 60, 'featured-section-new-to-imac_2x1493467732.jpg'),
(24, 60, 'image0011493467732.png'),
(25, 60, 'image001_21493467732.jpg'),
(26, 60, 'image001_111493467732.jpg'),
(29, 63, '5190001_sa.jpg'),
(30, 63, '5190001_sa.jpg'),
(31, 63, '1466960633738_19141493468586.jpg'),
(32, 63, '1466960633738_19141493468706.jpg'),
(33, 63, 'featured-section-new-to-imac_2x1493468926.jpg'),
(34, 63, '5190001_sa.jpg'),
(38, 61, '1466960639886_19201493470147.jpg'),
(43, 62, '5190001_sa.jpg'),
(44, 62, '5190001_sa.jpg'),
(45, 62, 'featured-section-new-to-imac_2x1493471267.jpg'),
(46, 51, '5190001_sa.jpg'),
(47, 51, '5190001_sa.jpg'),
(48, 45, '5190001_sa.jpg'),
(49, 45, '5190001_sa.jpg'),
(50, 45, '1466960633738_19141493616068.jpg'),
(51, 85, '2-a89056cf-a3ca-4d58-952e-5dcfaaae8d8b1493695704.jpg'),
(52, 85, '3-4a620da2-d3d1-46b3-82b7-6522066a48ed1493695704.jpg'),
(53, 85, 'canon-eos-1d-x-1-1-min1493695704.jpg'),
(54, 85, 'canon-eos-1d-x-2-1-min1493695704.jpg'),
(55, 86, '2-a89056cf-a3ca-4d58-952e-5dcfaaae8d8b1493696681.jpg'),
(56, 86, 'canon-6d-1-1-min1493696682.jpg'),
(57, 86, 'canon-eos-1d-x-2-1-min1493696682.jpg'),
(64, 88, '2-a89056cf-a3ca-4d58-952e-5dcfaaae8d8b1493995899.jpg'),
(65, 88, '3-4a620da2-d3d1-46b3-82b7-6522066a48ed1493995899.jpg'),
(66, 88, 'canon-6d-1-1-min1493995899.jpg'),
(67, 88, 'canon-eos-1d-x-1-1-min1493995899.jpg'),
(79, 90, '50255958752895701512031536.png'),
(80, 90, '74652537370051001512031536.png'),
(81, 90, '80289829538760701512031536.png'),
(82, 89, 'dum1517247854.png'),
(83, 89, 'indian-flag1517247854.png'),
(84, 89, 'japan-flag1517247854.jpg');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hieusp`
--

CREATE TABLE `hieusp` (
  `idhieusp` int(11) NOT NULL,
  `tenhieusp` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `tinhtrang` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `hieusp`
--

INSERT INTO `hieusp` (`idhieusp`, `tenhieusp`, `tinhtrang`) VALUES
(1, 'Sony', '1'),
(2, 'Dell', '1'),
(3, 'HP', '1'),
(4, 'Asus', '1'),
(5, 'Lenovo', '1'),
(11, 'Samsung', '1'),
(14, 'Apple', '1'),
(15, 'KhÃ¡c', '1');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `loaisp`
--

CREATE TABLE `loaisp` (
  `idloaisp` int(11) NOT NULL,
  `tenloaisp` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `tinhtrang` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `loaisp`
--

INSERT INTO `loaisp` (`idloaisp`, `tenloaisp`, `tinhtrang`) VALUES
(10, 'PC', '1'),
(11, 'Laptop', '1'),
(13, 'Bá»™ sáº¡c', '1'),
(17, 'Loa nghe nháº¡c', '1'),
(18, 'Tai nghe', '1'),
(19, 'Thiáº¿t bá»‹ an ninh', '1'),
(20, 'Tháº» nhá»› USB', '1'),
(21, 'Thiáº¿t bá»‹ máº¡ng', '1'),
(22, 'Sáº£n pháº©m khÃ¡c', '1'),
(24, 'Macbook pro', '1');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `sanpham`
--

CREATE TABLE `sanpham` (
  `idsanpham` int(11) NOT NULL,
  `tensp` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `masp` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `hinhanh` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `giadexuat` float NOT NULL,
  `giagiam` float NOT NULL,
  `soluong` int(11) NOT NULL,
  `loaisp` int(11) NOT NULL,
  `nhasx` int(11) NOT NULL,
  `tinhtrang` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `noidung` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `sanpham`
--

INSERT INTO `sanpham` (`idsanpham`, `tensp`, `masp`, `hinhanh`, `giadexuat`, `giagiam`, `soluong`, `loaisp`, `nhasx`, `tinhtrang`, `noidung`) VALUES
(38, 'Macbook Pro', 'M50', 'featured-section-new-to-imac_2x.jpg', 500000, 39, 1, 9, 3, '1', '<p>Ä‘áº¹p</p>'),
(48, 'Laptop Asus Vivobook', 'Asus1', '636716713670487885_Asus-S15-3.png', 15000000, 14500000, 4, 11, 4, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(83, 'Bá»™ Sáº¡c Dell', 'BS1', 'adaptor_dell_90w_1.jpg', 199000, 195000, 10, 13, 2, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(85, 'Canon EOS-1D X', 'canon', 'canon-eos-1d-x-1-1-min.jpg', 12000000, 12000000, 6, 22, 15, '1', '<p>Sáº£n pháº«m h&agrave;ng ch&iacute;nh h&atilde;ng v&agrave; ráº¥t l&agrave; Ä‘áº¹p.</p>'),
(86, 'Canon EOS 6D', 'canon 6d', '3-4a620da2-d3d1-46b3-82b7-6522066a48ed.jpg', 27000000, 27000000, 6, 22, 15, '1', '<p>Äáº¹p</p>'),
(88, 'Macbook pro 2017', 'mp67', 'download (1).jpg', 22000000, 19000000, 100, 24, 14, '1', '<p>Macbook pro qu&aacute; Ä‘áº¹p ,nhÆ°ng qu&aacute; máº¯c.</p>'),
(92, 'Laptop Dell', 'Dell', 'laptop-dell-inspiron.jpg', 20000000, 19000000, 5, 11, 2, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(93, 'Tai nghe', 'TN1', 'tai-nghe-chup-tai-ovann-x4-den-do-8195-7878852-ca1aa00b14c481b2d777db4310d21140.jpg', 350000, 340000, 10, 18, 15, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(94, 'Tai nghe', 'TN2', 'download.jpg', 200000, 190000, 10, 18, 15, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(95, 'Loa nghe nháº¡c', 'Loa1', '15941492122893665_Loa-bluetooth-loa-di-dong-loa-khong-day-sony-srs-xb10-black-1.jpg', 200000, 190000, 20, 17, 1, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(96, 'Loa nghe nháº¡c Sony SRS', 'Loa2', 'sony-srs-xb40-2640-75855044-37845d1a42baf4e0060e3f77e5e8dbbc.jpg_500x500Q80.jpg', 500000, 499999, 10, 17, 1, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(97, 'Camera An ninh', 'CAN1', 'camera-an-ninh-302G.jpg.png', 525000, 500000, 5, 19, 15, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(98, 'Camera An ninh', 'CAN2', 'ip7361.png', 450000, 440000, 5, 19, 15, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(99, 'Thiáº¿t bá»‹ máº¡ng-TPlink', 'TBM1', 'thiet-bi-mang-khong-day-tplink-tl-wr841nd-1.jpg', 700000, 650000, 5, 21, 15, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(100, 'Thiáº¿t bá»‹ máº¡ng Asus-BRT', 'TBM2', 'Thiet-bi-mang-Asus-BRT-AC828-jpg.jpg', 2000000, 1900000, 5, 21, 4, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(101, 'Tháº» nhá»› ', 'TN1', 'su-dung-khe-cam-laptop-9.jpg', 300000, 290000, 20, 20, 15, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(102, 'USB -Sandisk', 'USB1', 'usb-sandisk-sdcz50-8gb-20-7-600x600.jpg', 300000, 290000, 20, 20, 15, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(103, 'USB Sandisk', 'USB2', 'LD0001130547_2.jpg', 190000, 180000, 20, 20, 15, '1', '<p>H&Agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(104, 'Bá»™ Sáº¡c Dell', 'BS2', 'dell-1.jpg', 300000, 250000, 10, 13, 2, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(105, 'Bá»™ sáº¡c Asus', 'BS3', 'Asus_3.jpg', 200000, 180000, 10, 13, 4, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(106, 'Tai nghe in-ear', 'TN5', '636012407293657222_00003463.jpg', 350000, 320000, 10, 18, 15, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(107, 'Laptop HP', 'LHP1', 'ban-laptop-hp-probook-4430s-core-i5-ram-ddr3-hdd-o-cung-gia-re-quan-3.jpg', 25000000, 24000000, 5, 11, 3, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(108, 'Laptop Asus Vivobook-s350', 'LA2', 'laptop_asus_s530ua_1_2.jpg', 17000000, 16500000, 5, 11, 4, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(109, 'Laptop Dell', 'LD1', '1558434050_1478956.jpg', 30000000, 28000000, 5, 11, 2, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(110, 'Laptop Sony Vaio', 'LS1', '4106217_Sony_Vaio_FS830.jpg', 20000000, 19000000, 5, 11, 1, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(111, 'Macbook pro 2018', 'MBP1', 'acz0v2mr9653.jpg', 35000000, 33000000, 5, 24, 14, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(112, 'Macbook pro 2016', 'MBP2', '436246-apple-macbook-pro-13-inch-touch-bar-2016.jpg', 25000000, 24000000, 5, 24, 14, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(113, 'Laptop Lenovo ideapad', 'LL1', 'lenovo-ideapad-130-14ikb-81h60017vn-ava-600x600.jpg', 22000000, 21000000, 5, 11, 5, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(114, 'Laptop Samsung', 'LSS1', '6332955_sd.jpg', 20000000, 19000000, 5, 11, 11, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(115, 'Laptop LenovoThinkpad', 'LL2', '41+I90wQDUL._SX466_.jpg', 25000000, 24000000, 5, 11, 5, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(116, 'PC Dell Vostro', 'PCD1', 'may-tinh-de-ban-pc-dell-vostro-3470-sff-i5-8400-4gb-1tb-70157884-1.jpg', 15000000, 14000000, 10, 10, 2, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(117, 'PC Dell', 'PCD2', '41n-ozPiDhL._SY450_.jpg', 13000000, 12000000, 5, 10, 2, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(118, 'PC Asus Gaming', 'PCA1', 'LD0004987438_2.jpg', 30000000, 29000000, 10, 10, 4, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(119, 'PC Asus', 'PCA2', '201904AM120000001_15550055754186220067464.jpg', 16000000, 16000000, 10, 10, 4, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(120, 'PC HP', 'PCHP1', '14102-1.jpg', 10000000, 10000000, 10, 10, 3, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>'),
(121, 'PC HP-Prodesk', 'PCHP2', 'pc-hp-prodesk-400-g6-mt-600x400.jpg', 16000000, 15500000, 5, 10, 3, '1', '<p>H&agrave;ng ch&iacute;nh h&atilde;ng</p>');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tintuc`
--

CREATE TABLE `tintuc` (
  `idtintuc` int(11) NOT NULL,
  `tentintuc` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `matin` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `hinhanh` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `noidung` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `tinhtrang` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `tintuc`
--

INSERT INTO `tintuc` (`idtintuc`, `tentintuc`, `matin`, `hinhanh`, `noidung`, `tinhtrang`) VALUES
(2, 'Nhiá»u di Ä‘á»™ng bom táº¥n giáº£m giÃ¡ tiá»n triá»‡u trong thÃ¡ng 4', 't2', 'Jet.jpg', 'ThÃ¡ng 4 chá»©ng kiáº¿n biáº¿n Ä‘á»™ng lá»›n vá» giÃ¡ cá»§a nhiá»u di Ä‘á»™ng cao cáº¥p bá»Ÿi Ä‘Ã¢y lÃ  thá»i Ä‘iá»ƒm thá»‹ trÆ°á»ng chÃ o Ä‘Ã³n nhiá»u model Ä‘á»i má»›i.\r\nNhieu di dong bom tan giam gia tien trieu trong thang 4 hinh anh 1\r\niPhone 7, 7 Plus Jet Black (giáº£m 3 triá»‡u Ä‘á»“ng): Tá»« chá»— lÃ  smartphone hot nháº¥t trÃªn thá»‹ trÆ°á»ng, iPhone Jet Black giá» Ä‘Ã¢y trá»Ÿ thÃ nh máº·t hÃ ng áº¿ áº©m, cáº§n giáº£m giÃ¡ Ä‘á»ƒ thanh lÃ½. Tá»« hÃ ng xÃ¡ch tay cho Ä‘áº¿n chÃ­nh hÃ£ng, ngÆ°á»i dÃ¹ng Ä‘á»u Ä‘ang chá»©ng kiáº¿n mÃ n giáº£m giÃ¡ cá»§a nhá»¯ng chiáº¿c iPhone thá»i thÆ°á»£ng nÃ y. CÃ¡c Ä‘áº¡i lÃ½ lá»›n Ä‘ang cÃ´ng bá»‘ chÆ°Æ¡ng trÃ¬nh giáº£m giÃ¡ lÃªn Ä‘áº¿n 3 triá»‡u cho iPhone Jet Black. Cháº³ng háº¡n, iPhone 7 128 GB Jet Black giá» Ä‘Ã¢y cÃ³ giÃ¡ bÃ¡n chá»‰ 18,8 triá»‡u Ä‘á»“ng, 7 Plus lÃ  22,2 triá»‡u Ä‘á»“ng.', '1'),
(5, '3 máº«u Ä‘iá»‡n thoáº¡i PhÃ¡p thiáº¿t káº¿ Ä‘áº¹p, giÃ¡ dÆ°á»›i 4 triá»‡u Ä‘á»“ng', 'y6', 'image001_11.jpg', 'Ufeel vÃ  Ufeel Go\r\nSá»Ÿ há»¯u nhiá»u thÃ´ng sá»‘ tÆ°Æ¡ng Ä‘á»“ng, bá»™ Ä‘Ã´i Ufeel vÃ  Ufeel Go lÃ  Ä‘áº¡i diá»‡n hiáº¿m hoi cÃ³ má»©c giÃ¡ dÆ°á»›i 3,999 triá»‡u Ä‘á»“ng sá»Ÿ há»¯u cáº£m biáº¿n vÃ¢n tay. Äiá»ƒm Ä‘áº·c biá»‡t, cáº£m biáº¿n nÃ y cÃ³ kháº£ nÄƒng nháº­n diá»‡n 5 dáº¥u vÃ¢n tay. Vá»›i má»—i ngÃ³n tay khÃ¡c nhau, mÃ¡y sáº½ khá»Ÿi cháº¡y nhá»¯ng á»©ng dá»¥ng riÃªng biá»‡t Ä‘Ã£ gÃ¡n sáºµn.\r\n\r\nMÃ¡y há»— trá»£ 4G, má»Ÿ khÃ³a báº±ng vÃ¢n tay vÃ  cháº¡y Android 6.0 Marshmallow - nhá»¯ng yáº¿u tá»‘ hÃ ng Ä‘áº§u chá»n mua smartphone hiá»‡n nay. Hai thiáº¿t bá»‹ nÃ y Ä‘Æ°á»£c trang bá»‹ thanh RAM 3 GB.', '1');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`idadmin`);

--
-- Chỉ mục cho bảng `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `cart_detail`
--
ALTER TABLE `cart_detail`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `dangky`
--
ALTER TABLE `dangky`
  ADD PRIMARY KEY (`id_khachhang`);

--
-- Chỉ mục cho bảng `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id_gallery`);

--
-- Chỉ mục cho bảng `hieusp`
--
ALTER TABLE `hieusp`
  ADD PRIMARY KEY (`idhieusp`);

--
-- Chỉ mục cho bảng `loaisp`
--
ALTER TABLE `loaisp`
  ADD PRIMARY KEY (`idloaisp`);

--
-- Chỉ mục cho bảng `sanpham`
--
ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`idsanpham`);

--
-- Chỉ mục cho bảng `tintuc`
--
ALTER TABLE `tintuc`
  ADD PRIMARY KEY (`idtintuc`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `admin`
--
ALTER TABLE `admin`
  MODIFY `idadmin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT cho bảng `cart_detail`
--
ALTER TABLE `cart_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT cho bảng `dangky`
--
ALTER TABLE `dangky`
  MODIFY `id_khachhang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT cho bảng `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id_gallery` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT cho bảng `hieusp`
--
ALTER TABLE `hieusp`
  MODIFY `idhieusp` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT cho bảng `loaisp`
--
ALTER TABLE `loaisp`
  MODIFY `idloaisp` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT cho bảng `sanpham`
--
ALTER TABLE `sanpham`
  MODIFY `idsanpham` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;

--
-- AUTO_INCREMENT cho bảng `tintuc`
--
ALTER TABLE `tintuc`
  MODIFY `idtintuc` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
