// JavaScript Document
$('.delete_link').on('click',function(){
	var thongbao='Bạn có muốn xóa sản phẩm?';
	return confirm(thongbao);
    
});
	
	
	
	
