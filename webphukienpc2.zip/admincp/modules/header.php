<div class="header">
    	<h3>Welcome to Shop</h3>
    </div>